package br.com.artelecom.model;

public enum TipoPessoa {
    CLIENTE,
    FUNCIONARIO
}
