package br.com.artelecom.model;

import java.time.LocalDate;

public class Contrato {

    private Integer id;
    private Integer cliente_id;
    private Integer plano_id;
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private Double valorFinal;

    public Contrato() {
    }

    public Contrato(Integer cliente_id, Integer plano_id) {
        this.cliente_id = cliente_id;
        this.plano_id = plano_id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCliente_id() {
        return cliente_id;
    }

    public void setCliente_id(Integer cliente_id) {
        this.cliente_id = cliente_id;
    }

    public Integer getPlano_id() {
        return plano_id;
    }

    public void setPlano_id(Integer plano_id) {
        this.plano_id = plano_id;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public Double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(Double valorFinal) {
        this.valorFinal = valorFinal;
    }

    

}
