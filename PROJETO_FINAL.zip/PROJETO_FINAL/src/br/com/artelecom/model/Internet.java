package br.com.artelecom.model;

public class Internet extends Planos {

    private int velocidade;
    private Double valor;

    public Internet() {
    }

    public Internet(Double valor, int velocidade) {
        this.valor = valor;
        this.velocidade = velocidade;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

}
