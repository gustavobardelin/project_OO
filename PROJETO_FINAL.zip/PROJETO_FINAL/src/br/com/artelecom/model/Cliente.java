package br.com.artelecom.model;


public class Cliente extends Pessoa{
    
    private String endereco;
    private TipoCliente tipoCliente;


    public Cliente(String endereco, TipoCliente tipoCliente, Integer id, String nome, String cpf, String telefone, String email, TipoPessoa tipoPessoa) {
        super(id, nome, cpf, telefone, email, tipoPessoa);
        this.endereco = endereco;
        this.tipoCliente = tipoCliente;
    }

    public Cliente() {
        
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public TipoCliente getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(TipoCliente tipoCliente) {
        this.tipoCliente = tipoCliente;
    }
    
    
    
}
