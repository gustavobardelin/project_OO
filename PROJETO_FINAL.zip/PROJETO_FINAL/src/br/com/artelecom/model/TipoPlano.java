package br.com.artelecom.model;

public enum TipoPlano {
    INTERNET,
    TV
}
