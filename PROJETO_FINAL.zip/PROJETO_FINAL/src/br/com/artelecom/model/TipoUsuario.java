package br.com.artelecom.model;

public enum TipoUsuario {
    COMERCIAL,
    ADMINISTRATIVO,
    TECNICO,
    ATENDIMENTO
}

