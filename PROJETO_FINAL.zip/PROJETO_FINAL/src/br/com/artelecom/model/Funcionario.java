package br.com.artelecom.model;

public class Funcionario extends Pessoa{
    private String login;
    private String pass;
    private TipoUsuario tipoUsuario;

    public Funcionario(String login, String pass, TipoUsuario tipoUsuario, Integer id, String nome, String cpf, String telefone, String email, TipoPessoa tipoPessoa) {
        super(id, nome, cpf, telefone, email, tipoPessoa);
        this.login = login;
        this.pass = pass;
        this.tipoUsuario = tipoUsuario;
    }

    public Funcionario() {
       
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(TipoUsuario tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
    
    
    
}
