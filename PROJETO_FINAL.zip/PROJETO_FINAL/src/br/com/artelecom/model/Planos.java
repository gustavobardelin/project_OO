package br.com.artelecom.model;

public class Planos {

    private Integer id;
    private String nomePlano;
    private TipoPlano tipoPlano;

    public Planos() {
    }

    public Planos(String nomePlano, TipoPlano tipoPlano) {
        this.nomePlano = nomePlano;
        this.tipoPlano = tipoPlano;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomePlano() {
        return nomePlano;
    }

    public void setNomePlano(String nomePlano) {
        this.nomePlano = nomePlano;
    }

    public TipoPlano getTipoPlano() {
        return tipoPlano;
    }

    public void setTipoPlano(TipoPlano tipoPlano) {
        this.tipoPlano = tipoPlano;
    }

}
