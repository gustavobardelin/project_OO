package br.com.artelecom.model;

public enum TipoCliente {
    RESIDENCIAL,
    EMPRESARIAL
}

