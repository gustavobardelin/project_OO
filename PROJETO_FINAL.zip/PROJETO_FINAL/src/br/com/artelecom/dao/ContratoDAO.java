package br.com.artelecom.dao;

import br.com.artelecom.model.Contrato;
import java.sql.*;
import java.time.LocalDate;
import javax.swing.JOptionPane;



public class ContratoDAO {
    
    private Connection connection = ConnectionBD.getConnection();
    
    public void criarNovoContrato(Contrato contrato){
        
        String sql = "INSERT INTO contrato (cliente_id, plano_id, dataInicio, dataFim, valorFinal) VALUES (?, ?, ?, ?, ?)";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);
                    
            LocalDate dataInicio = LocalDate.now(); 
            LocalDate dataFim = dataInicio.plusYears(1);

            ps.setInt(1, contrato.getCliente_id());
            ps.setInt(2, contrato.getPlano_id());
            ps.setString(3, dataInicio.toString()); 
            ps.setString(4, dataFim.toString()); 
            ps.setDouble(5, contrato.getValorFinal()); 

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Contrato salvo com sucesso!");
            
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao salvar o contrato: " + e.getMessage());
        }
    }
    
    public ResultSet getContratos() {
        
        PreparedStatement ps;
        ResultSet rs = null;  

        String sql = """
            SELECT ct.id,
                   p.nome, 
                   p.cpf, 
                   pl.nomePlano, 
                   pl.tipoPlano, 
                   ct.dataInicio, 
                   ct.dataFim, 
                   ct.valorFinal
            FROM contrato ct
            INNER JOIN cliente c ON ct.cliente_id = c.id
            INNER JOIN pessoa p ON c.id = p.id
            INNER JOIN planos pl ON ct.plano_id = pl.id;
        """;

        try {
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();  // Executa a consulta e atribui o resultado a rs
            return rs;  // Retorna o ResultSet em caso de sucesso

        } catch (SQLException e) {
            // Imprime o stack trace do erro para depuração
            e.printStackTrace();

            // Lança uma exceção de tempo de execução com a mensagem de erro
            throw new RuntimeException("Erro ao executar a consulta SQL: " + e.getMessage(), e);
        }
    }
    
    public void atualizarContrato(Contrato contrato) {
        
        PreparedStatement ps;
        ResultSet rs = null;
        
        String sql = "UPDATE contrato SET plano_id = ?, dataInicio = ?, dataFim = ?, valorFinal = ? WHERE id = ?";

        try{
            ps = connection.prepareStatement(sql);

            LocalDate dataInicio = LocalDate.now(); 
            LocalDate dataFim = dataInicio.plusYears(1);

            ps.setInt(1, contrato.getPlano_id());
            ps.setString(2, dataInicio.toString()); 
            ps.setString(3, dataFim.toString()); 
            ps.setDouble(4, contrato.getValorFinal()); 
            ps.setInt(5, contrato.getId());   

            ps.execute();
            
            JOptionPane.showMessageDialog(null, "Contrato atualizado com sucesso!");
            

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro de banco de dados: " + e.getMessage());
        }
    }
    
    public void deletarContrato(int contratoId) {
        
        PreparedStatement ps;
        ResultSet rs = null;
        
        String sql = "DELETE FROM contrato WHERE id = ?";

        try {
            ps = connection.prepareStatement(sql);
            
            ps.setInt(1, contratoId); 
            ps.execute(); 


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
}
