package br.com.artelecom.dao;

import br.com.artelecom.model.Internet;
import br.com.artelecom.model.Planos;
import java.sql.*;

import javax.swing.JOptionPane;

public class PlanosDAO {

    private Connection connection = ConnectionBD.getConnection();

    public void salvarPlano(Planos plano){

        String sql = "INSERT INTO planos(nomePlano, tipoPlano) VALUES (?,?)";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, plano.getNomePlano());
            ps.setString(2, plano.getTipoPlano().toString());

            ps.execute();

            JOptionPane.showMessageDialog(null, "Plano Cadastrado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }


    public void saveTipoPlanoInternet(Internet planoInternet){

        String sql = "INSERT INTO internet(id, velocidade, valor) VALUES (LAST_INSERT_ID(), ?,?)";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setInt(1, planoInternet.getVelocidade());
            ps.setDouble(2, planoInternet.getValor());

            ps.execute();

            JOptionPane.showMessageDialog(null, "Plano de Internet Cadastrado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void salvaOuAtualizar(Planos plano){

        if (plano.getId() == null) {
            salvarPlano(plano);
        }else{
            updatePlano(plano);
        }

    }

    
    public void updatePlano(Planos plano){

        String sql = "UPDATE planos SET nomePlano=?, tipoPlano=? WHERE id=?";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, plano.getNomePlano());
            ps.setString(2, plano.getTipoPlano().toString());
            ps.setInt(3, plano.getId());

            ps.execute();

            JOptionPane.showMessageDialog(null, "Plano Atualizado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void updatePlanoInternet(Internet internet){

        String sql = "UPDATE internet SET velocidade=?, valor=? WHERE id=?";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setInt(1, internet.getVelocidade());
            ps.setDouble(2, internet.getValor());
            ps.setInt(3, internet.getId());


            ps.execute();

            JOptionPane.showMessageDialog(null, "Plano de Internet Atualizado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public void deletePlano(Planos plano){

        String sql = "DELETE FROM planos WHERE id=?";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setInt(1, plano.getId());
            ps.execute();

            JOptionPane.showMessageDialog(null, "Plano deletado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    
    public ResultSet getPlanos(){

        PreparedStatement ps;
        ResultSet rs;

        String sql = "SELECT p.id AS ID, p.nomePlano, p.tipoPlano, i.velocidade, i.valor FROM Planos p JOIN Internet i ON p.id = i.id";
            
            try {

                ps = connection.prepareStatement(sql);
                rs = ps.executeQuery();

                return rs;

            } catch (Exception e) {
               e.printStackTrace();
            }

        return null;
    }
    
}
