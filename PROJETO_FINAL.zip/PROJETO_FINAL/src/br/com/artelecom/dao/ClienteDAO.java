
package br.com.artelecom.dao;

import br.com.artelecom.model.Cliente;
import java.sql.*;
import javax.swing.JOptionPane;

public class ClienteDAO {
    
    private Connection connection = ConnectionBD.getConnection();
    private PessoaDAO pessoaDAO = new PessoaDAO();
    
    public void saveCliente(Cliente cliente){
        
        int idGerado = pessoaDAO.savePessoa(cliente);

        String sql = "INSERT INTO cliente(id, endereco, tipoCliente) VALUES (?,?,?)";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setInt(1, idGerado);
            ps.setString(2, cliente.getEndereco());
            ps.setString(3, cliente.getTipoCliente().toString());

            ps.execute();

            JOptionPane.showMessageDialog(null, "Cliente Cadastrada com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void updateCliente(Cliente cliente){
        
        pessoaDAO.updatePessoa(cliente);

        String sql = "UPDATE cliente SET endereco=?, tipoCliente=? WHERE id=?";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, cliente.getEndereco());
            ps.setString(2, cliente.getTipoCliente().toString());
            ps.setInt(3, cliente.getId());


            ps.execute();

            JOptionPane.showMessageDialog(null, "Cliente Atualizado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void deletarCliente(Cliente cliente) {
        pessoaDAO.deletePessoa(cliente);
    }
    
     public ResultSet getClientes(String pesquisa) {
         
        PreparedStatement ps;
        ResultSet rs;

        String sql = "SELECT p.id AS ID, p.nome, p.cpf, p.email, p.telefone, c.tipoCliente, c.endereco FROM Pessoa p JOIN Cliente c ON p.id = c.id WHERE nome like ? AND tipoPessoa = 'CLIENTE'";
            
        try {

            ps = connection.prepareStatement(sql);
            ps.setString(1, pesquisa + "%");
            rs = ps.executeQuery();

            return rs;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
     }
    
}
