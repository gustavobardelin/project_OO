package br.com.artelecom.dao;

import br.com.artelecom.model.Funcionario;
import java.sql.*;
import javax.swing.JOptionPane;

public class FuncionarioDAO {

    private Connection connection = ConnectionBD.getConnection();
    private PessoaDAO pessoaDAO = new PessoaDAO();
    private HashUtil hashUtil = new HashUtil();

    public void saveFuncionario(Funcionario funcionario) {

        int idGerado = pessoaDAO.savePessoa(funcionario);

        String sql = "INSERT INTO funcionario(id, login, pass, tipoUsuario) VALUES (?, ?, ?, ?)";

        try {
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setInt(1, idGerado);
            ps.setString(2, funcionario.getLogin());
            ps.setString(3, HashUtil.gerarHash(funcionario.getPass()));
            ps.setString(4, funcionario.getTipoUsuario().toString());

            ps.execute();

            JOptionPane.showMessageDialog(null, "Funcionario Cadastrado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void updateFuncionario(Funcionario funcionario) {

        pessoaDAO.updatePessoa(funcionario);

        String sql = "UPDATE funcionario SET login=?, pass=?, tipoUsuario=? WHERE id=?";

        try {
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, funcionario.getLogin());
            ps.setString(2, HashUtil.gerarHash(funcionario.getPass()));
            ps.setString(3, funcionario.getTipoUsuario().toString());
            ps.setInt(4, funcionario.getId());
            
            

            ps.execute();

            JOptionPane.showMessageDialog(null, "Funcionario Atualizado com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletarFuncionario(Funcionario funcionario) {
        pessoaDAO.deletePessoa(funcionario);
    }

    public ResultSet getFuncionarios(String pesquisa) {

        PreparedStatement ps;
        ResultSet rs;

        String sql = "SELECT p.id AS ID, p.nome, p.cpf, p.email, p.telefone, f.tipoUsuario AS Setor, f.login FROM Pessoa p JOIN Funcionario F ON p.id = f.id WHERE nome like ? AND tipoPessoa = 'FUNCIONARIO'";
        
        try {

            ps = connection.prepareStatement(sql);
            ps.setString(1, pesquisa + "%");
            rs = ps.executeQuery();

            return rs;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;

    }
    
     public boolean verificarCredenciais(String login, String senha) {
         
        PreparedStatement ps;
        ResultSet rs;

         
        String sql = "SELECT pass FROM funcionario WHERE login = ?";

        try{
            ps = connection.prepareStatement(sql);
            ps.setString(1, login);

            rs = ps.executeQuery();
            
            if (rs.next()) {
     
                String senhaHashBanco = rs.getString("pass");

               
                String senhaHashDigitada = HashUtil.gerarHash(senha);

                
                return senhaHashBanco.equals(senhaHashDigitada);
            
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        
        return false;
    }
}