package br.com.artelecom.dao;

import br.com.artelecom.model.Cliente;
import br.com.artelecom.model.Funcionario;
import br.com.artelecom.model.Pessoa;
import br.com.artelecom.model.TipoPessoa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PessoaDAO {
    
    private Connection connection = ConnectionBD.getConnection();
        
    public int savePessoa(Pessoa pessoa){

        String sql = "INSERT INTO pessoa(nome, cpf, telefone, email, tipoPessoa) VALUES (?,?,?,?,?)";
        int idGerado = 0;
        
        try{
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, pessoa.getNome());
            ps.setString(2, pessoa.getCpf());
            ps.setString(3, pessoa.getTelefone());
            ps.setString(4, pessoa.getEmail());
            ps.setString(5, pessoa.getTipoPessoa().toString());
            
            
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            
            
            if (rs.next()) {
                idGerado = rs.getInt(1);
            }

            
            ps.close();

            JOptionPane.showMessageDialog(null, "Pessoa Cadastrada com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return idGerado;

    }
    
    public void updatePessoa(Pessoa pessoa){

        String sql = "UPDATE pessoa SET nome=?, cpf=?, telefone=?, email=?, tipoPessoa=?  WHERE id=?";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setString(1, pessoa.getNome());
            ps.setString(2, pessoa.getCpf());
            ps.setString(3, pessoa.getTelefone());
            ps.setString(4, pessoa.getEmail());
            ps.setString(5, pessoa.getTipoPessoa().toString());
            ps.setInt(6, pessoa.getId());

            ps.execute();
            ps.close();

            JOptionPane.showMessageDialog(null, "Pessoa Atualizada com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    
    public void deletePessoa(Pessoa pessoa){

        String sql = "DELETE FROM pessoa WHERE id=?";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);

            ps.setInt(1, pessoa.getId());
            ps.execute();
            ps.close();

            JOptionPane.showMessageDialog(null, "Pessoa deletada com Sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    
     public List<Pessoa> getPessoas(){

         List<Pessoa> pessoas = new ArrayList<>();

        String sql = "SELECT * FROM pessoa";

        try{
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            ps.close(); 

            while(rs.next()){
                
                Pessoa pessoa;
                String tipoPessoa = rs.getString("tipoPessoa");
                
                if(tipoPessoa.equals(TipoPessoa.CLIENTE.toString())){
                    pessoa = new Cliente();
                }else if(tipoPessoa.equals(TipoPessoa.FUNCIONARIO.toString())){
                    pessoa = new Funcionario();
                }else{
                    continue;
                }

                pessoa.setId(rs.getInt("id"));
                pessoa.setNome(rs.getString("nome"));
                pessoa.setCpf(rs.getString("cpf"));
                pessoa.setTelefone(rs.getString("telefone"));
                pessoa.setEmail(rs.getString("email"));


                pessoas.add(pessoa);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return pessoas;


    }
    
}
