package br.com.artelecom.dao;

import java.sql.*;

public class ConnectionBD {

    public static Connection getConnection() {

        Connection conn = null;
        String driver = ("com.mysql.jdbc.Driver");
        
        String dbName = "telecom_db";
        String url = "jdbc:mysql://localhost:3306/" + dbName;
        String user = "root";
        String pass = "gusta";
        
        try {
            //Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pass);
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;

    }

}
