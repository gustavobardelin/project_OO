package br.com.artelecom.controller;

import br.com.artelecom.dao.FuncionarioDAO;
import br.com.artelecom.model.Funcionario;
import br.com.artelecom.model.Pessoa;
import java.sql.ResultSet;

public class FuncionarioController extends PessoaController{
    
    FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

    @Override
    public void inserir(Pessoa pessoa) throws Exception {
       funcionarioDAO.saveFuncionario((Funcionario)pessoa);
    }

    @Override
    public void update(Pessoa pessoa) throws Exception {
        funcionarioDAO.updateFuncionario((Funcionario)pessoa);
    }

    @Override
    public void delete(Pessoa pessoa) throws Exception {
       funcionarioDAO.deletarFuncionario((Funcionario)pessoa);
    }

    @Override
    public ResultSet exibir(String pesquisa) throws Exception {
        return funcionarioDAO.getFuncionarios(pesquisa);
    }
    
    public boolean getLogin(String login, String pass){
         
        return funcionarioDAO.verificarCredenciais(login, pass);
    }
    
    
    
}
