package br.com.artelecom.controller;

import br.com.artelecom.dao.ClienteDAO;
import br.com.artelecom.model.Cliente;
import br.com.artelecom.model.Pessoa;
import java.sql.ResultSet;

public class ClienteController extends PessoaController{
    
    ClienteDAO clienteDAO = new ClienteDAO();

    @Override
    public void inserir(Pessoa pessoa) throws Exception {
        clienteDAO.saveCliente((Cliente)pessoa);  
    }

    @Override
    public void update(Pessoa pessoa) throws Exception {
       clienteDAO.updateCliente((Cliente)pessoa);
    }

    @Override
    public void delete(Pessoa pessoa) throws Exception {
        clienteDAO.deletarCliente((Cliente)pessoa);
    }

    @Override
    public ResultSet exibir(String pesquisa) throws Exception {
       return clienteDAO.getClientes(pesquisa);
    }
    
}
