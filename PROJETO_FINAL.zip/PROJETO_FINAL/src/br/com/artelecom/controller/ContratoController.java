package br.com.artelecom.controller;

import br.com.artelecom.dao.ContratoDAO;
import br.com.artelecom.model.Contrato;
import java.sql.*;


public class ContratoController {
    
    private ContratoDAO contratoDAO = new ContratoDAO();
    
    public void criarContrato(Contrato contrato){
        contratoDAO.criarNovoContrato(contrato);
    }
    
    public ResultSet getContratos(){
        return contratoDAO.getContratos();
    }
    
    public void atualizaContrato(Contrato contrato){
        contratoDAO.atualizarContrato(contrato);
    }
    
    public void deletarContrato(Contrato contrato){
        contratoDAO.deletarContrato(contrato.getId());
    }
    
}
