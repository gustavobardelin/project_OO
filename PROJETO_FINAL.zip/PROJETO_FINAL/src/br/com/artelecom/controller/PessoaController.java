package br.com.artelecom.controller;

import br.com.artelecom.model.Pessoa;
import java.sql.ResultSet;

public abstract class PessoaController {
   
    public PessoaController() {
    }
    
    public abstract void inserir(Pessoa pessoa) throws Exception;
    public abstract void update(Pessoa pessoa) throws Exception;
    public abstract void delete(Pessoa pessoa) throws Exception;
    public abstract ResultSet exibir(String pesquisa) throws Exception;
    
}
