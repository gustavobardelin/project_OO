package br.com.artelecom.controller;

import br.com.artelecom.dao.PlanosDAO;
import br.com.artelecom.model.Internet;
import br.com.artelecom.model.Planos;
import java.sql.*;

public class PlanosController {

    PlanosDAO planoDAO = new PlanosDAO();

    public void salvarPlano(Planos plano){
        planoDAO.salvaOuAtualizar(plano);
    }

    public void salvarPlanoInternet(Internet internet){
        planoDAO.saveTipoPlanoInternet(internet);

    }

    public void deletePlano(Planos plano){
        planoDAO.deletePlano(plano);
    }

    public void updatePlano(Planos plano, Internet internet){

        planoDAO.salvaOuAtualizar(plano);
        planoDAO.updatePlanoInternet(internet);
    }
    
    public ResultSet getPlanos(){
        return planoDAO.getPlanos();
    }
    
}
